﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAuthorizations
{
    class Helper
    {
        private static Module.telecompanyEntities1 s_entities;
        public static Module.telecompanyEntities1 GetContext()
        {
            if (s_entities == null)
            {
                s_entities = new Module.telecompanyEntities1();
            }
            return s_entities;
        }

        public static void CreateEmployees(Module.Employees employees, Module.Authorization authorizations)
        {
            s_entities.Employees.Add(employees);
            s_entities.Authorization.Add(authorizations);
            s_entities.SaveChanges();
        }

        public static int GetLastIDStaff()
        {
            int id = s_entities.Employees.OrderByDescending(employees => employees.ID).First().ID;

            return id + 1;
        }

        public static int GetLastIDAuth()
        {
            int id = s_entities.Authorization.OrderByDescending(authorizations => authorizations.ID).First().ID;
            return id + 1;
        }
    }
}
