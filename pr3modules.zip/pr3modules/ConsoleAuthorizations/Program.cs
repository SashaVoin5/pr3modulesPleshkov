﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleAuthorizations.Module;
using HashPasswords;

namespace ConsoleAuthorizations
{
    class Program
    {
       
        static void Main(string[] args)

        {
            int a = 1;
            while (a!=0)
            {
                try
                {

                    Helper m = new Helper();
                    telecompanyEntities1 ms = Helper.GetContext();
                    Console.WriteLine("Cоздание новой учетной записи");
                    Console.Write("");
                    Console.Write("Введите имя сотрудника:");
                    string name = Console.ReadLine();
                    Console.Write("Введите фамилию сотрудника:");
                    string Last_Name = Console.ReadLine();
                    Console.Write("Введите отчество сотрудника:");
                    string Middle_Name = Console.ReadLine();
                    Console.Write("Введите дату рождения сотрудника:");
                    string born = Console.ReadLine();
                    Console.Write("Введите айди семейного статуса сотрудника:");
                    int idStatus = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Введите айди пола сотрудника:");
                    int idGender = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Введите адрес сотрудника: ");
                    string adress = Console.ReadLine();
                    Console.Write("Введите айди специальности сотрудника:");
                    int idSpec = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Введите логин сотрудника: ");
                    string login = Console.ReadLine();
                    Console.Write("Введите пароль сотрудника: ");
                    string password = Console.ReadLine();

                    if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(Last_Name)
                        && string.IsNullOrEmpty(born) && string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password)
                         || string.IsNullOrEmpty(adress))


                    {
                        Console.WriteLine("Не все нужные данные введены");
                    }
                    else if (int.TryParse(name, out int n) || int.TryParse(Last_Name, out int s)
                        || int.TryParse(login, out int l))
                    {
                        Console.WriteLine("Неправильно введены данные");
                    }
                    else if (DateTime.TryParseExact(born, "dd.MM.yyyy", null, System.Globalization.DateTimeStyles.None, out DateTime dt))
                    {

                        HashPassword hash = new HashPassword();
                        Console.WriteLine($"Хешированный пароль пользователя: {hash.HashPassw(password)}");
                        hash.HashPassw(password);
                        int staff = Helper.GetLastIDStaff();
                        int authid = Helper.GetLastIDAuth();
                        Employees staffs = new Employees { ID = staff, AuthorizationID = authid, First_Name = name, Last_Name = Last_Name, Middle_Name = Middle_Name, GenderID = idGender, Family_statusID = idStatus, Address = adress, SpecialityID = idSpec };
                        Authorization authorization = new Authorization { ID = authid, Login = login, Password = hash.HashPassw(password) };
                        Helper.CreateEmployees(staffs, authorization);
                        Console.WriteLine("Учетная запись добавлена");
                        Console.WriteLine();
                        Console.WriteLine("Если вы хотите закончить,введите число 0.Если хотите продолжить введите  любое другое число");
                        a = Convert.ToInt32(Console.ReadLine());
                        Console.Write("");

                    }
                    else
                    {
                        Console.WriteLine("Неправильный ввод даты");
                    }

                }
                catch
                {
                    Console.WriteLine("Ошибка");
                }
                if (a==0)
                    Console.WriteLine("Приятных выходных!");
            }
            
        }
    }
}
